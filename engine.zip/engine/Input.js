class Input {
  constructor(dom) {
    this.keys = {};
    this.mouse = { x: 0, y: 0 };

    onkeydown = e => this.keys[e.key.toLowerCase()] = true;
    onkeyup = e => this.keys[e.key.toLowerCase()] = false;

    dom.onclick = () => dom.requestPointerLock();

    addEventListener("mousemove", e => {
      if (document.pointerLockElement === dom) {
        this.mouse.x += e.movementX;
        this.mouse.y += e.movementY;
      }
    });
  }
}

window.Input = Input;
