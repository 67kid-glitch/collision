class Chunk {
  constructor(cx, cz) {
    this.cx = cx;
    this.cz = cz;
    this.size = 16;
    this.blocks = new Uint8Array(16 * 16 * 16);

    for (let x = 0; x < 16; x++)
      for (let z = 0; z < 16; z++)
        this.set(x, 0, z, Blocks.GRASS);
  }

  index(x, y, z) {
    return x + y * 16 + z * 256;
  }

  get(x, y, z) {
    return this.blocks[this.index(x, y, z)];
  }

  set(x, y, z, id) {
    this.blocks[this.index(x, y, z)] = id;
  }
}

window.Chunk = Chunk;
