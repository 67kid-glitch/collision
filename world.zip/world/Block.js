window.Blocks = {
  AIR: 0,
  GRASS: 1,
  STONE: 2
};

window.BlockInfo = {
  0: { solid: false },
  1: { solid: true },
  2: { solid: true }
};
