class World {
  constructor(scene) {
    this.scene = scene;
    this.chunks = {};
    this.meshes = [];

    for (let x = -1; x <= 1; x++)
      for (let z = -1; z <= 1; z++)
        this.addChunk(x, z);
  }

  key(x, z) {
    return x + "," + z;
  }

  addChunk(cx, cz) {
    const chunk = new Chunk(cx, cz);
    this.chunks[this.key(cx, cz)] = chunk;

    const geo = new THREE.BoxGeometry(1,1,1);
    const mat = new THREE.MeshLambertMaterial({ color: 0x22aa22 });

    for (let x = 0; x < 16; x++)
      for (let z = 0; z < 16; z++) {
        const m = new THREE.Mesh(geo, mat);
        m.position.set(cx * 16 + x, 0, cz * 16 + z);
        this.scene.add(m);
        this.meshes.push(m);
      }
  }

  isSolid(x, y, z) {
    if (y !== 0) return false;
    return true;
  }
}

window.World = World;
