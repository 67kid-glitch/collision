class Player {
  constructor(camera, input, world) {
    this.camera = camera;
    this.input = input;
    this.world = world;
    this.vel = new THREE.Vector3();
    this.mode = "survival";
    this.onGround = false;

    addEventListener("keydown", e => {
      if (e.key === "g") {
        this.mode = this.mode === "survival" ? "creative" : "survival";
      }
    });
  }

  update() {
    this.camera.rotation.order = "YXZ";
    this.camera.rotation.y -= this.input.mouse.x * 0.002;
    this.camera.rotation.x -= this.input.mouse.y * 0.002;
    this.camera.rotation.x = Math.max(-1.5, Math.min(1.5, this.camera.rotation.x));
    this.input.mouse.x = this.input.mouse.y = 0;

    const dir = new THREE.Vector3();
    if (this.input.keys.w) dir.z -= 1;
    if (this.input.keys.s) dir.z += 1;
    if (this.input.keys.a) dir.x -= 1;
    if (this.input.keys.d) dir.x += 1;
    dir.normalize().applyEuler(this.camera.rotation);

    if (this.mode === "creative") {
      if (this.input.keys[" "]) dir.y += 1;
      if (this.input.keys.shift) dir.y -= 1;
      this.camera.position.add(dir.multiplyScalar(0.2));
      return;
    }

    this.vel.x = dir.x * 0.15;
    this.vel.z = dir.z * 0.15;
    this.vel.y -= 0.02;

    if (this.onGround && this.input.keys[" "]) {
      this.vel.y = 0.35;
      this.onGround = false;
    }

    this.camera.position.add(this.vel);

    if (this.camera.position.y <= 2) {
      this.camera.position.y = 2;
      this.vel.y = 0;
      this.onGround = true;
    }
  }
}

window.Player = Player;
