class Loop {
  constructor(game) {
    this.game = game;
    const tick = () => {
      requestAnimationFrame(tick);
      game.update();
    };
    tick();
  }
}

window.Loop = Loop;
