class Game {
  constructor() {
    this.renderer = new Renderer();
    this.input = new Input(this.renderer.renderer.domElement);
    this.world = new World(this.renderer.scene);
    this.player = new Player(this.renderer.camera, this.input, this.world);
  }

  update() {
    this.player.update();
    this.renderer.render();
  }
}

window.Game = Game;
